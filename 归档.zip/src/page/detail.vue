<template>
	<div class="page">
         <span class="name">fghfhf</span>
	</div>
</template>
<script>
// import FN from "../js/common/fn";
// import Api from "../js/lib/Api";
// import axios from 'axios'
export default {
  data() {
    return {
      user: []
    };
  },
  created() {
  
  },
  mounted() {},

  methods: {
  
  }
};
</script>
<style scoped>
.name {
  font-size: 25px;
  color: red
}
</style>
