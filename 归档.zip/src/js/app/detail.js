import Vue from 'vue'
import App from '@/page/detail.vue'
import  '@/css/rest.css'

import  '@/css/a.less'

new Vue({
    el:'#app',
    template:'<App/>',
    components:{App}
})